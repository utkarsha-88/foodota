package com.coforge.training.foodota.model;


public class CustomerOrder {

}
